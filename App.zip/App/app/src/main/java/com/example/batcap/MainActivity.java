package com.example.batcap;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.CompoundButton;

import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(MonitorWorker.class).build();

        findViewById(R.id.enableFunction).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    Log.d("alarmCheck","ALARM SET TO TRUE");
                    //                sched.setAlarm(true);
                    WorkManager.getInstance().enqueue(workRequest);
                }
                else
                {
                    Log.d("alarmCheck","ALARM SET TO FALSE");
                    //                sched.setAlarm(false);
                }

            }
        });
    }

}
